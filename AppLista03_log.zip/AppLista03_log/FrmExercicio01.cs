﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_log
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            //Capturar os valores da tela
            float num1 = float.Parse(txtnum1.Text);
            float num3 = float.Parse(txtnum3.Text);
            float soma;

            //Realizar Soma
            soma = num1 + num3;

            //Mostrar Resultado
            MessageBox.Show("Soma = " + soma);


        }

        private void btnmedia_Click(object sender, EventArgs e)
        {

            //Capturar os valores da tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float media;

            //Calcular a media
            media = (num1 + num2 + num3) / 3;

            //Mostrar o resultado
            MessageBox.Show("Media = " + media);
        }

        private void btnporcentagen_Click(object sender, EventArgs e)
        {
            //Capturar os valores da tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float porc1, porc2, porc3;

            //Cálculos
            porc1 = num1 / (num1 + num2 + num3) * 100;
            porc2 = num2 / (num1 + num1 + num3) * 100;
            porc3 = num2 / (num1 + num2 + num3) * 100;

            MessageBox.Show("Porcentag.num1 =" + porc1);
            MessageBox.Show("Porcentag.num2 =" + porc2);
            MessageBox.Show("Porcentag.num3 =" + porc3);
        } 
    }
}
