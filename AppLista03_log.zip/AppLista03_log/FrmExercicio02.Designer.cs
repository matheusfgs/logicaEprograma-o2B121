﻿namespace AppLista03_log
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtpaga = new System.Windows.Forms.TextBox();
            this.lblValorDePagamento = new System.Windows.Forms.Label();
            this.lblValorDaGasolina = new System.Windows.Forms.Label();
            this.txtgas = new System.Windows.Forms.TextBox();
            this.btncalc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "EXERCÍCIO 2";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtpaga
            // 
            this.txtpaga.Location = new System.Drawing.Point(28, 122);
            this.txtpaga.Multiline = true;
            this.txtpaga.Name = "txtpaga";
            this.txtpaga.Size = new System.Drawing.Size(288, 26);
            this.txtpaga.TabIndex = 1;
            this.txtpaga.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblValorDePagamento
            // 
            this.lblValorDePagamento.AutoSize = true;
            this.lblValorDePagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorDePagamento.Location = new System.Drawing.Point(27, 94);
            this.lblValorDePagamento.Name = "lblValorDePagamento";
            this.lblValorDePagamento.Size = new System.Drawing.Size(205, 25);
            this.lblValorDePagamento.TabIndex = 2;
            this.lblValorDePagamento.Text = "Valor do pagamento";
            // 
            // lblValorDaGasolina
            // 
            this.lblValorDaGasolina.AutoSize = true;
            this.lblValorDaGasolina.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorDaGasolina.Location = new System.Drawing.Point(27, 209);
            this.lblValorDaGasolina.Name = "lblValorDaGasolina";
            this.lblValorDaGasolina.Size = new System.Drawing.Size(179, 25);
            this.lblValorDaGasolina.TabIndex = 3;
            this.lblValorDaGasolina.Text = "Valor da gasolina";
            // 
            // txtgas
            // 
            this.txtgas.Location = new System.Drawing.Point(32, 246);
            this.txtgas.Multiline = true;
            this.txtgas.Name = "txtgas";
            this.txtgas.Size = new System.Drawing.Size(288, 26);
            this.txtgas.TabIndex = 4;
            this.txtgas.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btncalc
            // 
            this.btncalc.BackColor = System.Drawing.Color.Teal;
            this.btncalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalc.Location = new System.Drawing.Point(146, 306);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(547, 103);
            this.btncalc.TabIndex = 5;
            this.btncalc.Text = "Quantidade de litros abastecidos";
            this.btncalc.UseVisualStyleBackColor = false;
            this.btncalc.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(856, 456);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.txtgas);
            this.Controls.Add(this.lblValorDaGasolina);
            this.Controls.Add(this.lblValorDePagamento);
            this.Controls.Add(this.txtpaga);
            this.Controls.Add(this.label1);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.Load += new System.EventHandler(this.FrmExercicio02_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpaga;
        private System.Windows.Forms.Label lblValorDePagamento;
        private System.Windows.Forms.Label lblValorDaGasolina;
        private System.Windows.Forms.TextBox txtgas;
        private System.Windows.Forms.Button btncalc;
    }
}