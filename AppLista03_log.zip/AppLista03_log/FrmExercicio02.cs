﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_log
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void FrmExercicio02_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            








       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Capturar os Valores da tela

            float num1 = float.Parse(txtpaga.Text);
            float num2 = float.Parse(txtgas.Text);
            float pagamento;

            //Calculo

            pagamento = num1 / (num2);

            MessageBox.Show("Valor de pagamento:" + pagamento);



        }
    }
}
