﻿namespace lista03exepag
{
    partial class FrmLista3atv
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnltitulo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlprodutos = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtproduto3 = new System.Windows.Forms.TextBox();
            this.txtproduto2 = new System.Windows.Forms.TextBox();
            this.txtproduto1 = new System.Windows.Forms.TextBox();
            this.pnlresultados = new System.Windows.Forms.Panel();
            this.lblres5 = new System.Windows.Forms.Label();
            this.lblres4 = new System.Windows.Forms.Label();
            this.lblres3 = new System.Windows.Forms.Label();
            this.lblres2 = new System.Windows.Forms.Label();
            this.lblres1 = new System.Windows.Forms.Label();
            this.lblparcela5 = new System.Windows.Forms.Label();
            this.lblparcela4 = new System.Windows.Forms.Label();
            this.lclparcela3 = new System.Windows.Forms.Label();
            this.lclparcela2 = new System.Windows.Forms.Label();
            this.lblparcela1 = new System.Windows.Forms.Label();
            this.btncalcular = new System.Windows.Forms.Button();
            this.pnltitulo.SuspendLayout();
            this.pnlprodutos.SuspendLayout();
            this.pnlresultados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnltitulo
            // 
            this.pnltitulo.BackColor = System.Drawing.Color.LightBlue;
            this.pnltitulo.Controls.Add(this.label1);
            this.pnltitulo.Location = new System.Drawing.Point(12, 12);
            this.pnltitulo.Name = "pnltitulo";
            this.pnltitulo.Size = new System.Drawing.Size(868, 78);
            this.pnltitulo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Display", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(263, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(363, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "LOJA DE GAMES";
            // 
            // pnlprodutos
            // 
            this.pnlprodutos.BackColor = System.Drawing.Color.LightBlue;
            this.pnlprodutos.Controls.Add(this.label7);
            this.pnlprodutos.Controls.Add(this.label6);
            this.pnlprodutos.Controls.Add(this.label5);
            this.pnlprodutos.Controls.Add(this.label4);
            this.pnlprodutos.Controls.Add(this.label3);
            this.pnlprodutos.Controls.Add(this.label2);
            this.pnlprodutos.Controls.Add(this.txtPreco3);
            this.pnlprodutos.Controls.Add(this.txtPreco2);
            this.pnlprodutos.Controls.Add(this.txtPreco1);
            this.pnlprodutos.Controls.Add(this.txtproduto3);
            this.pnlprodutos.Controls.Add(this.txtproduto2);
            this.pnlprodutos.Controls.Add(this.txtproduto1);
            this.pnlprodutos.Location = new System.Drawing.Point(50, 122);
            this.pnlprodutos.Name = "pnlprodutos";
            this.pnlprodutos.Size = new System.Drawing.Size(499, 294);
            this.pnlprodutos.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(295, 215);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 25);
            this.label7.TabIndex = 10;
            this.label7.Text = "Preço 3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(295, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "Preço 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(295, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Preço 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Produto 3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Produto 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Produto 1";
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(300, 243);
            this.txtPreco3.Multiline = true;
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(166, 29);
            this.txtPreco3.TabIndex = 5;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(300, 153);
            this.txtPreco2.Multiline = true;
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(166, 29);
            this.txtPreco2.TabIndex = 4;
            // 
            // txtPreco1
            // 
            this.txtPreco1.Location = new System.Drawing.Point(300, 54);
            this.txtPreco1.Multiline = true;
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(166, 29);
            this.txtPreco1.TabIndex = 3;
            // 
            // txtproduto3
            // 
            this.txtproduto3.Location = new System.Drawing.Point(29, 243);
            this.txtproduto3.Multiline = true;
            this.txtproduto3.Name = "txtproduto3";
            this.txtproduto3.Size = new System.Drawing.Size(166, 29);
            this.txtproduto3.TabIndex = 2;
            // 
            // txtproduto2
            // 
            this.txtproduto2.Location = new System.Drawing.Point(29, 153);
            this.txtproduto2.Multiline = true;
            this.txtproduto2.Name = "txtproduto2";
            this.txtproduto2.Size = new System.Drawing.Size(166, 29);
            this.txtproduto2.TabIndex = 1;
            // 
            // txtproduto1
            // 
            this.txtproduto1.Location = new System.Drawing.Point(29, 54);
            this.txtproduto1.Multiline = true;
            this.txtproduto1.Name = "txtproduto1";
            this.txtproduto1.Size = new System.Drawing.Size(166, 29);
            this.txtproduto1.TabIndex = 0;
            // 
            // pnlresultados
            // 
            this.pnlresultados.BackColor = System.Drawing.SystemColors.GrayText;
            this.pnlresultados.Controls.Add(this.lblres5);
            this.pnlresultados.Controls.Add(this.lblres4);
            this.pnlresultados.Controls.Add(this.lblres3);
            this.pnlresultados.Controls.Add(this.lblres2);
            this.pnlresultados.Controls.Add(this.lblres1);
            this.pnlresultados.Controls.Add(this.lblparcela5);
            this.pnlresultados.Controls.Add(this.lblparcela4);
            this.pnlresultados.Controls.Add(this.lclparcela3);
            this.pnlresultados.Controls.Add(this.lclparcela2);
            this.pnlresultados.Controls.Add(this.lblparcela1);
            this.pnlresultados.Location = new System.Drawing.Point(591, 122);
            this.pnlresultados.Name = "pnlresultados";
            this.pnlresultados.Size = new System.Drawing.Size(247, 294);
            this.pnlresultados.TabIndex = 2;
            // 
            // lblres5
            // 
            this.lblres5.AutoSize = true;
            this.lblres5.Location = new System.Drawing.Point(182, 248);
            this.lblres5.Name = "lblres5";
            this.lblres5.Size = new System.Drawing.Size(10, 13);
            this.lblres5.TabIndex = 9;
            this.lblres5.Text = "-";
            // 
            // lblres4
            // 
            this.lblres4.AutoSize = true;
            this.lblres4.Location = new System.Drawing.Point(182, 198);
            this.lblres4.Name = "lblres4";
            this.lblres4.Size = new System.Drawing.Size(10, 13);
            this.lblres4.TabIndex = 8;
            this.lblres4.Text = "-";
            // 
            // lblres3
            // 
            this.lblres3.AutoSize = true;
            this.lblres3.Location = new System.Drawing.Point(182, 147);
            this.lblres3.Name = "lblres3";
            this.lblres3.Size = new System.Drawing.Size(10, 13);
            this.lblres3.TabIndex = 7;
            this.lblres3.Text = "-";
            // 
            // lblres2
            // 
            this.lblres2.AutoSize = true;
            this.lblres2.Location = new System.Drawing.Point(182, 89);
            this.lblres2.Name = "lblres2";
            this.lblres2.Size = new System.Drawing.Size(10, 13);
            this.lblres2.TabIndex = 6;
            this.lblres2.Text = "-";
            // 
            // lblres1
            // 
            this.lblres1.AutoSize = true;
            this.lblres1.Location = new System.Drawing.Point(182, 38);
            this.lblres1.Name = "lblres1";
            this.lblres1.Size = new System.Drawing.Size(10, 13);
            this.lblres1.TabIndex = 5;
            this.lblres1.Text = "-";
            // 
            // lblparcela5
            // 
            this.lblparcela5.AutoSize = true;
            this.lblparcela5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela5.Location = new System.Drawing.Point(41, 242);
            this.lblparcela5.Name = "lblparcela5";
            this.lblparcela5.Size = new System.Drawing.Size(102, 19);
            this.lblparcela5.TabIndex = 4;
            this.lblparcela5.Text = "5 parcelas de:";
            // 
            // lblparcela4
            // 
            this.lblparcela4.AutoSize = true;
            this.lblparcela4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela4.Location = new System.Drawing.Point(41, 192);
            this.lblparcela4.Name = "lblparcela4";
            this.lblparcela4.Size = new System.Drawing.Size(102, 19);
            this.lblparcela4.TabIndex = 3;
            this.lblparcela4.Text = "4 parcelas de:";
            // 
            // lclparcela3
            // 
            this.lclparcela3.AutoSize = true;
            this.lclparcela3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lclparcela3.Location = new System.Drawing.Point(41, 141);
            this.lclparcela3.Name = "lclparcela3";
            this.lclparcela3.Size = new System.Drawing.Size(102, 19);
            this.lclparcela3.TabIndex = 2;
            this.lclparcela3.Text = "3 parcelas de:";
            // 
            // lclparcela2
            // 
            this.lclparcela2.AutoSize = true;
            this.lclparcela2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lclparcela2.Location = new System.Drawing.Point(41, 85);
            this.lclparcela2.Name = "lclparcela2";
            this.lclparcela2.Size = new System.Drawing.Size(102, 19);
            this.lclparcela2.TabIndex = 1;
            this.lclparcela2.Text = "2 parcelas de:";
            // 
            // lblparcela1
            // 
            this.lblparcela1.AutoSize = true;
            this.lblparcela1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela1.Location = new System.Drawing.Point(41, 32);
            this.lblparcela1.Name = "lblparcela1";
            this.lblparcela1.Size = new System.Drawing.Size(102, 19);
            this.lblparcela1.TabIndex = 0;
            this.lblparcela1.Text = "1 parcelas de:";
            // 
            // btncalcular
            // 
            this.btncalcular.Font = new System.Drawing.Font("Segoe UI Historic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalcular.Location = new System.Drawing.Point(50, 422);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(788, 37);
            this.btncalcular.TabIndex = 3;
            this.btncalcular.Text = "calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // FrmLista3atv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(892, 471);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.pnlresultados);
            this.Controls.Add(this.pnlprodutos);
            this.Controls.Add(this.pnltitulo);
            this.Name = "FrmLista3atv";
            this.Text = "FrmLista3atv";
            this.pnltitulo.ResumeLayout(false);
            this.pnltitulo.PerformLayout();
            this.pnlprodutos.ResumeLayout(false);
            this.pnlprodutos.PerformLayout();
            this.pnlresultados.ResumeLayout(false);
            this.pnlresultados.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnltitulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlprodutos;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.TextBox txtproduto3;
        private System.Windows.Forms.TextBox txtproduto2;
        private System.Windows.Forms.TextBox txtproduto1;
        private System.Windows.Forms.Panel pnlresultados;
        private System.Windows.Forms.Label lblparcela1;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Label lblparcela5;
        private System.Windows.Forms.Label lblparcela4;
        private System.Windows.Forms.Label lclparcela3;
        private System.Windows.Forms.Label lclparcela2;
        private System.Windows.Forms.Label lblres5;
        private System.Windows.Forms.Label lblres4;
        private System.Windows.Forms.Label lblres3;
        private System.Windows.Forms.Label lblres2;
        private System.Windows.Forms.Label lblres1;
    }
}

