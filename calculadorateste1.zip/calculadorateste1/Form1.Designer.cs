﻿namespace calculadorateste1
{
    partial class Frmcalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBarraDeResolução = new System.Windows.Forms.TextBox();
            this.btnMC = new System.Windows.Forms.Button();
            this.btnMR = new System.Windows.Forms.Button();
            this.btnMS = new System.Windows.Forms.Button();
            this.btnMplus = new System.Windows.Forms.Button();
            this.btnMmenos = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.btnsetaesquerda = new System.Windows.Forms.Button();
            this.btnZero = new System.Windows.Forms.Button();
            this.btnmais = new System.Windows.Forms.Button();
            this.btnvirgula = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.btnmultiplicação = new System.Windows.Forms.Button();
            this.btndivisão = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btnoito = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnCE = new System.Windows.Forms.Button();
            this.btncC = new System.Windows.Forms.Button();
            this.btnraiz = new System.Windows.Forms.Button();
            this.btnmaismenos = new System.Windows.Forms.Button();
            this.btnquatro = new System.Windows.Forms.Button();
            this.btncinco = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btnum = new System.Windows.Forms.Button();
            this.btndois = new System.Windows.Forms.Button();
            this.btntres = new System.Windows.Forms.Button();
            this.btnchistorico = new System.Windows.Forms.Button();
            this.btnexibição = new System.Windows.Forms.Button();
            this.btnexpoente = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBarraDeResolução
            // 
            this.txtBarraDeResolução.Location = new System.Drawing.Point(12, 67);
            this.txtBarraDeResolução.Multiline = true;
            this.txtBarraDeResolução.Name = "txtBarraDeResolução";
            this.txtBarraDeResolução.Size = new System.Drawing.Size(344, 77);
            this.txtBarraDeResolução.TabIndex = 0;
            // 
            // btnMC
            // 
            this.btnMC.BackColor = System.Drawing.Color.Gainsboro;
            this.btnMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMC.Location = new System.Drawing.Point(-1, 175);
            this.btnMC.Name = "btnMC";
            this.btnMC.Size = new System.Drawing.Size(71, 60);
            this.btnMC.TabIndex = 1;
            this.btnMC.Text = "MC";
            this.btnMC.UseVisualStyleBackColor = false;
            // 
            // btnMR
            // 
            this.btnMR.BackColor = System.Drawing.Color.Silver;
            this.btnMR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMR.Location = new System.Drawing.Point(76, 175);
            this.btnMR.Name = "btnMR";
            this.btnMR.Size = new System.Drawing.Size(71, 60);
            this.btnMR.TabIndex = 2;
            this.btnMR.Text = "MR";
            this.btnMR.UseVisualStyleBackColor = false;
            this.btnMR.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnMS
            // 
            this.btnMS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMS.Location = new System.Drawing.Point(152, 175);
            this.btnMS.Name = "btnMS";
            this.btnMS.Size = new System.Drawing.Size(71, 60);
            this.btnMS.TabIndex = 3;
            this.btnMS.Text = "MS";
            this.btnMS.UseVisualStyleBackColor = false;
            this.btnMS.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnMplus
            // 
            this.btnMplus.BackColor = System.Drawing.Color.Silver;
            this.btnMplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMplus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnMplus.Location = new System.Drawing.Point(229, 175);
            this.btnMplus.Name = "btnMplus";
            this.btnMplus.Size = new System.Drawing.Size(71, 60);
            this.btnMplus.TabIndex = 4;
            this.btnMplus.Text = "M+";
            this.btnMplus.UseVisualStyleBackColor = false;
            this.btnMplus.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnMmenos
            // 
            this.btnMmenos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnMmenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMmenos.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnMmenos.Location = new System.Drawing.Point(306, 175);
            this.btnMmenos.Name = "btnMmenos";
            this.btnMmenos.Size = new System.Drawing.Size(71, 60);
            this.btnMmenos.TabIndex = 5;
            this.btnMmenos.Text = "M-";
            this.btnMmenos.UseVisualStyleBackColor = false;
            // 
            // btnIgual
            // 
            this.btnIgual.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIgual.Location = new System.Drawing.Point(315, 396);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(48, 190);
            this.btnIgual.TabIndex = 6;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = false;
            this.btnIgual.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnsetaesquerda
            // 
            this.btnsetaesquerda.Font = new System.Drawing.Font("Stencil", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsetaesquerda.Location = new System.Drawing.Point(-1, 262);
            this.btnsetaesquerda.Name = "btnsetaesquerda";
            this.btnsetaesquerda.Size = new System.Drawing.Size(70, 40);
            this.btnsetaesquerda.TabIndex = 7;
            this.btnsetaesquerda.Text = "<---";
            this.btnsetaesquerda.UseVisualStyleBackColor = true;
            // 
            // btnZero
            // 
            this.btnZero.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnZero.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZero.Location = new System.Drawing.Point(41, 504);
            this.btnZero.Name = "btnZero";
            this.btnZero.Size = new System.Drawing.Size(147, 44);
            this.btnZero.TabIndex = 8;
            this.btnZero.Text = "0";
            this.btnZero.UseVisualStyleBackColor = false;
            // 
            // btnmais
            // 
            this.btnmais.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnmais.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmais.Location = new System.Drawing.Point(229, 474);
            this.btnmais.Name = "btnmais";
            this.btnmais.Size = new System.Drawing.Size(80, 44);
            this.btnmais.TabIndex = 10;
            this.btnmais.Text = "+";
            this.btnmais.UseVisualStyleBackColor = false;
            // 
            // btnvirgula
            // 
            this.btnvirgula.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnvirgula.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvirgula.Location = new System.Drawing.Point(229, 524);
            this.btnvirgula.Name = "btnvirgula";
            this.btnvirgula.Size = new System.Drawing.Size(80, 44);
            this.btnvirgula.TabIndex = 11;
            this.btnvirgula.Text = ",";
            this.btnvirgula.UseVisualStyleBackColor = false;
            // 
            // btnmenos
            // 
            this.btnmenos.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnmenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmenos.Location = new System.Drawing.Point(229, 424);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(80, 44);
            this.btnmenos.TabIndex = 12;
            this.btnmenos.Text = "-";
            this.btnmenos.UseVisualStyleBackColor = false;
            // 
            // btnmultiplicação
            // 
            this.btnmultiplicação.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnmultiplicação.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmultiplicação.Location = new System.Drawing.Point(229, 374);
            this.btnmultiplicação.Name = "btnmultiplicação";
            this.btnmultiplicação.Size = new System.Drawing.Size(80, 44);
            this.btnmultiplicação.TabIndex = 13;
            this.btnmultiplicação.Text = "x";
            this.btnmultiplicação.UseVisualStyleBackColor = false;
            // 
            // btndivisão
            // 
            this.btndivisão.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btndivisão.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndivisão.Location = new System.Drawing.Point(229, 324);
            this.btndivisão.Name = "btndivisão";
            this.btndivisão.Size = new System.Drawing.Size(80, 44);
            this.btndivisão.TabIndex = 14;
            this.btndivisão.Text = "/";
            this.btndivisão.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(12, 328);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(58, 44);
            this.btn7.TabIndex = 22;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            // 
            // btnoito
            // 
            this.btnoito.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnoito.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnoito.Location = new System.Drawing.Point(85, 328);
            this.btnoito.Name = "btnoito";
            this.btnoito.Size = new System.Drawing.Size(57, 44);
            this.btnoito.TabIndex = 23;
            this.btnoito.Text = "8";
            this.btnoito.UseVisualStyleBackColor = false;
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(157, 328);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(55, 44);
            this.btn9.TabIndex = 24;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            // 
            // btnCE
            // 
            this.btnCE.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCE.Location = new System.Drawing.Point(81, 262);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(70, 40);
            this.btnCE.TabIndex = 25;
            this.btnCE.Text = "CE";
            this.btnCE.UseVisualStyleBackColor = true;
            // 
            // btncC
            // 
            this.btncC.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncC.Location = new System.Drawing.Point(158, 262);
            this.btncC.Name = "btncC";
            this.btncC.Size = new System.Drawing.Size(58, 40);
            this.btncC.TabIndex = 26;
            this.btncC.Text = "C";
            this.btncC.UseVisualStyleBackColor = true;
            // 
            // btnraiz
            // 
            this.btnraiz.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnraiz.Location = new System.Drawing.Point(298, 262);
            this.btnraiz.Name = "btnraiz";
            this.btnraiz.Size = new System.Drawing.Size(70, 40);
            this.btnraiz.TabIndex = 27;
            this.btnraiz.Text = "√";
            this.btnraiz.UseVisualStyleBackColor = true;
            // 
            // btnmaismenos
            // 
            this.btnmaismenos.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmaismenos.Location = new System.Drawing.Point(222, 262);
            this.btnmaismenos.Name = "btnmaismenos";
            this.btnmaismenos.Size = new System.Drawing.Size(70, 40);
            this.btnmaismenos.TabIndex = 28;
            this.btnmaismenos.Text = "+-";
            this.btnmaismenos.UseVisualStyleBackColor = true;
            // 
            // btnquatro
            // 
            this.btnquatro.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnquatro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnquatro.Location = new System.Drawing.Point(12, 388);
            this.btnquatro.Name = "btnquatro";
            this.btnquatro.Size = new System.Drawing.Size(58, 44);
            this.btnquatro.TabIndex = 29;
            this.btnquatro.Text = "4";
            this.btnquatro.UseVisualStyleBackColor = false;
            // 
            // btncinco
            // 
            this.btncinco.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btncinco.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncinco.Location = new System.Drawing.Point(85, 388);
            this.btncinco.Name = "btncinco";
            this.btncinco.Size = new System.Drawing.Size(58, 44);
            this.btncinco.TabIndex = 30;
            this.btncinco.Text = "5";
            this.btncinco.UseVisualStyleBackColor = false;
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(157, 388);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(58, 44);
            this.btn6.TabIndex = 31;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            // 
            // btnum
            // 
            this.btnum.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnum.Location = new System.Drawing.Point(12, 454);
            this.btnum.Name = "btnum";
            this.btnum.Size = new System.Drawing.Size(58, 44);
            this.btnum.TabIndex = 32;
            this.btnum.Text = "1";
            this.btnum.UseVisualStyleBackColor = false;
            // 
            // btndois
            // 
            this.btndois.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btndois.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndois.Location = new System.Drawing.Point(84, 454);
            this.btndois.Name = "btndois";
            this.btndois.Size = new System.Drawing.Size(58, 44);
            this.btndois.TabIndex = 33;
            this.btndois.Text = "2";
            this.btndois.UseVisualStyleBackColor = false;
            // 
            // btntres
            // 
            this.btntres.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btntres.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntres.Location = new System.Drawing.Point(157, 454);
            this.btntres.Name = "btntres";
            this.btntres.Size = new System.Drawing.Size(58, 44);
            this.btntres.TabIndex = 34;
            this.btntres.Text = "3";
            this.btntres.UseVisualStyleBackColor = false;
            // 
            // btnchistorico
            // 
            this.btnchistorico.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnchistorico.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchistorico.Location = new System.Drawing.Point(195, 29);
            this.btnchistorico.Name = "btnchistorico";
            this.btnchistorico.Size = new System.Drawing.Size(163, 32);
            this.btnchistorico.TabIndex = 35;
            this.btnchistorico.Text = "Histórico";
            this.btnchistorico.UseVisualStyleBackColor = false;
            // 
            // btnexibição
            // 
            this.btnexibição.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnexibição.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexibição.Location = new System.Drawing.Point(12, 29);
            this.btnexibição.Name = "btnexibição";
            this.btnexibição.Size = new System.Drawing.Size(163, 32);
            this.btnexibição.TabIndex = 36;
            this.btnexibição.Text = "Exibição";
            this.btnexibição.UseVisualStyleBackColor = false;
            this.btnexibição.Click += new System.EventHandler(this.btnexibição_Click);
            // 
            // btnexpoente
            // 
            this.btnexpoente.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnexpoente.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexpoente.Location = new System.Drawing.Point(315, 324);
            this.btnexpoente.Name = "btnexpoente";
            this.btnexpoente.Size = new System.Drawing.Size(53, 66);
            this.btnexpoente.TabIndex = 37;
            this.btnexpoente.Text = "x^y";
            this.btnexpoente.UseVisualStyleBackColor = false;
            // 
            // Frmcalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(370, 588);
            this.Controls.Add(this.btnexpoente);
            this.Controls.Add(this.btnexibição);
            this.Controls.Add(this.btnchistorico);
            this.Controls.Add(this.btntres);
            this.Controls.Add(this.btndois);
            this.Controls.Add(this.btnum);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btncinco);
            this.Controls.Add(this.btnquatro);
            this.Controls.Add(this.btnmaismenos);
            this.Controls.Add(this.btnraiz);
            this.Controls.Add(this.btncC);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btnoito);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btndivisão);
            this.Controls.Add(this.btnmultiplicação);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btnvirgula);
            this.Controls.Add(this.btnmais);
            this.Controls.Add(this.btnZero);
            this.Controls.Add(this.btnsetaesquerda);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.btnMmenos);
            this.Controls.Add(this.btnMplus);
            this.Controls.Add(this.btnMS);
            this.Controls.Add(this.btnMR);
            this.Controls.Add(this.btnMC);
            this.Controls.Add(this.txtBarraDeResolução);
            this.Name = "Frmcalculadora";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBarraDeResolução;
        private System.Windows.Forms.Button btnMC;
        private System.Windows.Forms.Button btnMR;
        private System.Windows.Forms.Button btnMS;
        private System.Windows.Forms.Button btnMplus;
        private System.Windows.Forms.Button btnMmenos;
        private System.Windows.Forms.Button btnIgual;
        private System.Windows.Forms.Button btnsetaesquerda;
        private System.Windows.Forms.Button btnZero;
        private System.Windows.Forms.Button btnmais;
        private System.Windows.Forms.Button btnvirgula;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button btnmultiplicação;
        private System.Windows.Forms.Button btndivisão;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btnoito;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnCE;
        private System.Windows.Forms.Button btncC;
        private System.Windows.Forms.Button btnraiz;
        private System.Windows.Forms.Button btnmaismenos;
        private System.Windows.Forms.Button btnquatro;
        private System.Windows.Forms.Button btncinco;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btnum;
        private System.Windows.Forms.Button btndois;
        private System.Windows.Forms.Button btntres;
        private System.Windows.Forms.Button btnchistorico;
        private System.Windows.Forms.Button btnexibição;
        private System.Windows.Forms.Button btnexpoente;
    }
}

